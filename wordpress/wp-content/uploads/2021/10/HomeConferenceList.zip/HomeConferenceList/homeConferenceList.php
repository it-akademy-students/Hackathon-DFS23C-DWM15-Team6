<?php
/*
 * Plugin Name:		Home Conference List
 * Description:		Liste réduite des conférences
 * Version:			1.0.0
 * WordPress URI:	
 * Plugin URI:		
 * Author:			Phoung
 */

function homeConferenceList(){
	$vu_conferenceList = '<div class="et_pb_section et_pb_section_1 et_section_regular">';

    global $wpdb;
    $conferences_table = $wpdb->prefix . 'conferences_table';
    $result = $wpdb->get_results("SELECT * FROM $conferences_table LIMIT 5 ORDER BY DESC");
    foreach ($results as $print) {
		$shortdescription = $print->description;
            if (strlen($print->description) >= 150){
              $shortdescription = substr($print->description, 0, 150) . ' [...]';
            } 
        $vu_conferenceList .= '
		<div class="box">
			<div class="et_pb_with_border et_pb_row et_pb_row_1 et_pb_equal_columns et_pb_gutters1">
				<div class="et_pb_column et_pb_column_1_5 et_pb_column_1  et_pb_css_mix_blend_mode_passthrough box_photo">
					<div class="et_pb_module et_pb_image et_pb_image_0">
						<span class="et_pb_image_wrap ">
							<img loading="lazy" width="129" height="130" src="'. $print->img .'" alt="photo conférencier" class="wp-image-24">
						</span>
					</div>
					<div class="lecturer_name">' . $print->lecturer_name . '</div>
				</div>
				<div class="et_pb_column et_pb_column_3_5 et_pb_column_2  et_pb_css_mix_blend_mode_passthrough">
				<div class="et_pb_module et_pb_text et_pb_text_1  et_pb_text_align_left et_pb_bg_layout_light">
					<div class="et_pb_text_inner">
						<h4>'.$print->name .'</h4>
						<p>' .$shortdescription .'</p>
					</div>
				</div>
			</div>
			<div class="et_pb_column et_pb_column_1_5 et_pb_column_3  et_pb_css_mix_blend_mode_passthrough et-last-child">
				<div class="et_pb_button_module_wrapper et_pb_button_0_wrapper  et_pb_module ">
					<a class="et_pb_button et_pb_button_0 et_pb_bg_layout_light" href="/details?id='.$print->conference_id .'">EN SAVOIR PLUS</a>
				</div>
			</div>
			</div>
		</div>
        ';
    }
    $vu_conferenceList .= '</div>';
	
	return $vu_conferenceList;
}
add_shortcode('homeConferenceList', 'homeConferenceList');